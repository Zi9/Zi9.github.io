Thank you for downloading Cinematic Tools for CarX Drift Racing Online

INSTALLATION:
Drag and drop the contents of the zip into your CarX folder
(usually C:\Program Files (x86)\Steam\steamapps\common\CarX Drift Racing Online)

Then once you start the game you should see green text in the top left corner on the loading screen indicating that Cinematic Tools has been enabled. Use the hotkey ALT+C to show the menu.

You can freely contact me on Discord for any further questions and ideas

-- Zi9