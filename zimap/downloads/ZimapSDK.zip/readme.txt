This is the Zimap SDK for use with Zi9's Map Loader

MapBuilder.exe has 2 functions:
    Double clicking it will generate an id.txt for your map
    Dropping a map folder onto it will build that map, the built map is saved in the dropped folder.
