This is a beta version of the loader

Report all bugs to Zi9#3641

Debug functions:
    Shift+F9 enable ReflectionProbe
    Shift+F10 disable ReflectionProbe
