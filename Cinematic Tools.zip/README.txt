Thank you for downloading Cinematic Tools for CarX Drift Racing Online

INSTALLATION:
Drag and drop the contents of the Cinematic Tools folder into your CarX folder
(usually C:\Program Files (x86)\Steam\steamapps\common\CarX Drift Racing Online)

Then once you start the game you should see green text in the top left corner on the loading screen indicating that Cinematic Tools has been enabled. Use the hotkey ALT+C to show the menu.

If you have the Community Sticker Pack installed too, you'll need to use the patched version from the Sticker Pack Patch folder
Just drag and drop that into the same CarX folder you dropped Cinematic Tools in and replace the files.

You can freely contact me on Discord for any further questions and ideas

-- Zi9