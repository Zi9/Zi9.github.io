Drag and drop the files from this zip into your CarX folder (usually C:\Program Files (x86)\Steam\steamapps\common\CarX Drift Racing Online)
and replace all files